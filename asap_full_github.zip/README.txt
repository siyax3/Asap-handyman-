Multi-page site bundle for ASAP Handyman & Plumbing.

Files to create/upload to your web host (place at site root):
- index.html
- services.html
- pricing.html
- about.html
- contact.html
- download.html
- css/styles.css
- js/main.js
- files/asap-service-file.pdf   (your downloadable file)
- /mnt/data/asap.jpg           (logo already present in conversation; replace path with /assets/asap.jpg if you upload it to server)

Important next steps:
1) Replace all placeholder phone numbers and email addresses with your real contact details.
2) Replace PayFast merchant_id & merchant_key in pricing.html when your PayFast account is active.
3) Upload files/asap-service-file.pdf and ensure download.html points to that path.
4) If your hosting doesn't allow the path /mnt/data/asap.jpg, upload the logo to the server (e.g. /assets/asap.jpg) and update the <img> src paths in the HTML files.
5) For contact form: replace the Formspree action with your Formspree ID or wire it to your backend.

Need me to:
- Package these into a zip and provide for download? (I can create files for you)
- Replace phone numbers, email, or logo path now? Reply with details and I'll update the files.

Thank you!