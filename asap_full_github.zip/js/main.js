// Simple client-side behaviors (expand later as needed)
document.addEventListener('DOMContentLoaded',function(){
  // simple mobile nav toggle could be added here in future
});